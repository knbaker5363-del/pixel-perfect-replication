import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, GraduationCap, Clock, CheckCircle } from "lucide-react"
import Link from "next/link"

export default async function AdminDashboardPage() {
  const supabase = await createServerClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Check if user is admin
  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

  if (profile?.role !== "admin") {
    redirect("/")
  }

  // Get statistics
  const [{ count: totalStudents }, { count: totalTeachers }, { count: pendingTeachers }, { count: totalSessions }] =
    await Promise.all([
      supabase.from("profiles").select("*", { count: "exact", head: true }).eq("role", "student"),
      supabase.from("teachers").select("*", { count: "exact", head: true }).eq("approval_status", "approved"),
      supabase.from("teachers").select("*", { count: "exact", head: true }).eq("approval_status", "pending"),
      supabase.from("sessions").select("*", { count: "exact", head: true }),
    ])

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      <div className="border-b border-border bg-card">
        <div className="container mx-auto px-6 py-4">
          <h1 className="text-2xl font-bold text-foreground">لوحة تحكم الإدارة</h1>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <Card className="border-border bg-card">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">إجمالي الطلاب</CardTitle>
              <Users className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">{totalStudents || 0}</div>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">المدرسون النشطون</CardTitle>
              <GraduationCap className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">{totalTeachers || 0}</div>
            </CardContent>
          </Card>

          <Card className="border-border bg-card border-orange-500/50">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">المدرسون المعلقون</CardTitle>
              <Clock className="h-4 w-4 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-500">{pendingTeachers || 0}</div>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">إجمالي الجلسات</CardTitle>
              <CheckCircle className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">{totalSessions || 0}</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Link href="/admin/teachers/pending">
            <Card className="border-border bg-card hover:border-primary/50 transition-colors cursor-pointer">
              <CardHeader>
                <CardTitle className="text-foreground flex items-center gap-2">
                  <Clock className="h-5 w-5 text-orange-500" />
                  طلبات المدرسين المعلقة
                </CardTitle>
                <CardDescription className="text-muted-foreground">قبول أو رفض طلبات التسجيل كمدرس</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-orange-500">{pendingTeachers || 0}</div>
                <p className="text-sm text-muted-foreground mt-2">طلب جديد في انتظار الموافقة</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/teachers">
            <Card className="border-border bg-card hover:border-primary/50 transition-colors cursor-pointer">
              <CardHeader>
                <CardTitle className="text-foreground flex items-center gap-2">
                  <GraduationCap className="h-5 w-5 text-primary" />
                  إدارة المدرسين
                </CardTitle>
                <CardDescription className="text-muted-foreground">عرض وإدارة جميع المدرسين</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">{totalTeachers || 0}</div>
                <p className="text-sm text-muted-foreground mt-2">مدرس نشط</p>
              </CardContent>
            </Card>
          </Link>
        </div>
      </div>
    </div>
  )
}

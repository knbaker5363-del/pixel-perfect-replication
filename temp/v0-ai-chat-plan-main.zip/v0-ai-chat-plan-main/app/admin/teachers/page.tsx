import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Mail, Phone, BookOpen, Star } from "lucide-react"

export default async function AllTeachersPage() {
  const supabase = await createServerClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Check if user is admin
  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

  if (profile?.role !== "admin") {
    redirect("/")
  }

  // Get all teachers
  const { data: teachers } = await supabase
    .from("teachers")
    .select(
      `
      *,
      profiles:id (
        full_name,
        email,
        phone,
        bio
      )
    `,
    )
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      <div className="border-b border-border bg-card">
        <div className="container mx-auto px-6 py-4">
          <h1 className="text-2xl font-bold text-foreground">إدارة المدرسين</h1>
          <p className="text-muted-foreground mt-1">عرض وإدارة جميع المدرسين في المنصة</p>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        {!teachers || teachers.length === 0 ? (
          <Card className="border-border bg-card">
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground">لا يوجد مدرسون مسجلون</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6">
            {teachers.map((teacher) => {
              const teacherProfile = teacher.profiles as any
              return (
                <Card key={teacher.id} className="border-border bg-card">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-foreground flex items-center gap-2">
                          {teacherProfile?.full_name}
                          <Badge
                            variant={
                              teacher.approval_status === "approved"
                                ? "default"
                                : teacher.approval_status === "rejected"
                                  ? "destructive"
                                  : "secondary"
                            }
                          >
                            {teacher.approval_status === "approved"
                              ? "مقبول"
                              : teacher.approval_status === "rejected"
                                ? "مرفوض"
                                : "قيد المراجعة"}
                          </Badge>
                        </CardTitle>
                        <CardDescription className="text-muted-foreground flex items-center gap-4 mt-2">
                          <span className="flex items-center gap-1">
                            <Mail className="h-4 w-4" />
                            {teacherProfile?.email}
                          </span>
                          {teacherProfile?.phone && (
                            <span className="flex items-center gap-1">
                              <Phone className="h-4 w-4" />
                              {teacherProfile.phone}
                            </span>
                          )}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-3 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">التخصص</p>
                        <p className="text-foreground font-medium flex items-center gap-2">
                          <BookOpen className="h-4 w-4 text-primary" />
                          {teacher.specialization}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">السعر بالساعة</p>
                        <p className="text-foreground font-medium">{teacher.hourly_rate} نقطة</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">التقييم</p>
                        <p className="text-foreground font-medium flex items-center gap-1">
                          <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                          {teacher.rating.toFixed(1)} ({teacher.total_sessions} جلسة)
                        </p>
                      </div>
                    </div>

                    {teacherProfile?.bio && (
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">نبذة عن المدرس</p>
                        <p className="text-foreground">{teacherProfile.bio}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Clock, Mail, Phone, BookOpen } from "lucide-react"
import { ApproveTeacherButton } from "@/components/approve-teacher-button"
import { RejectTeacherButton } from "@/components/reject-teacher-button"

export default async function PendingTeachersPage() {
  const supabase = await createServerClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Check if user is admin
  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

  if (profile?.role !== "admin") {
    redirect("/")
  }

  // Get pending teachers
  const { data: pendingTeachers } = await supabase
    .from("teachers")
    .select(
      `
      *,
      profiles:id (
        full_name,
        email,
        phone,
        bio,
        created_at
      )
    `,
    )
    .eq("approval_status", "pending")
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      <div className="border-b border-border bg-card">
        <div className="container mx-auto px-6 py-4">
          <h1 className="text-2xl font-bold text-foreground">طلبات المدرسين المعلقة</h1>
          <p className="text-muted-foreground mt-1">قبول أو رفض طلبات التسجيل كمدرس</p>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        {!pendingTeachers || pendingTeachers.length === 0 ? (
          <Card className="border-border bg-card">
            <CardContent className="py-12 text-center">
              <Clock className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">لا توجد طلبات معلقة في الوقت الحالي</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6">
            {pendingTeachers.map((teacher) => {
              const teacherProfile = teacher.profiles as any
              return (
                <Card key={teacher.id} className="border-border bg-card">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-foreground flex items-center gap-2">
                          {teacherProfile?.full_name}
                          <span className="text-sm font-normal px-2 py-1 rounded-full bg-orange-500/10 text-orange-500">
                            قيد المراجعة
                          </span>
                        </CardTitle>
                        <CardDescription className="text-muted-foreground flex items-center gap-4 mt-2">
                          <span className="flex items-center gap-1">
                            <Mail className="h-4 w-4" />
                            {teacherProfile?.email}
                          </span>
                          {teacherProfile?.phone && (
                            <span className="flex items-center gap-1">
                              <Phone className="h-4 w-4" />
                              {teacherProfile.phone}
                            </span>
                          )}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">التخصص</p>
                        <p className="text-foreground font-medium flex items-center gap-2">
                          <BookOpen className="h-4 w-4 text-primary" />
                          {teacher.specialization}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">السعر بالساعة</p>
                        <p className="text-foreground font-medium">{teacher.hourly_rate} نقطة</p>
                      </div>
                    </div>

                    {teacherProfile?.bio && (
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">نبذة عن المدرس</p>
                        <p className="text-foreground">{teacherProfile.bio}</p>
                      </div>
                    )}

                    <div className="flex gap-3 pt-4">
                      <ApproveTeacherButton teacherId={teacher.id} adminId={user.id} />
                      <RejectTeacherButton teacherId={teacher.id} adminId={user.id} />
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { email } = await request.json()

    if (!email) {
      return NextResponse.json({ error: "البريد الإلكتروني مطلوب" }, { status: 400 })
    }

    const supabase = await createClient()

    // Get user by email
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("id, email, role")
      .eq("email", email)
      .single()

    if (profileError || !profile) {
      return NextResponse.json({ error: "لم يتم العثور على مستخدم بهذا البريد الإلكتروني" }, { status: 404 })
    }

    // Update user role to admin
    const { error: updateError } = await supabase.from("profiles").update({ role: "admin" }).eq("id", profile.id)

    if (updateError) {
      console.error("[v0] Error updating user to admin:", updateError)
      return NextResponse.json({ error: "حدث خطأ أثناء تحديث الدور" }, { status: 500 })
    }

    // Delete from teachers/students tables if exists
    await supabase.from("teachers").delete().eq("id", profile.id)
    await supabase.from("students").delete().eq("id", profile.id)

    return NextResponse.json({
      success: true,
      message: "تم تحويل المستخدم إلى أدمن بنجاح",
    })
  } catch (error) {
    console.error("[v0] Error in make-admin API:", error)
    return NextResponse.json({ error: "حدث خطأ في الخادم" }, { status: 500 })
  }
}

import { generateText } from "ai"
import { NextResponse } from "next/server"

export async function POST(req: Request) {
  try {
    const { messages } = await req.json()

    // Generate response using AI SDK with Vercel AI Gateway
    const { text } = await generateText({
      model: "openai/gpt-4o-mini",
      system: `أنت مساعد تعليمي ذكي متخصص في مساعدة الطلاب الجامعيين في دراستهم. 
      
قواعد مهمة:
- تحدث باللغة العربية الفصحى بأسلوب واضح وبسيط
- ركز على شرح المفاهيم بطريقة تعليمية
- قدم أمثلة عملية عندما يكون ذلك مناسباً
- كن صبوراً ومشجعاً
- إذا كان السؤال خارج نطاق التعليم، وجه الطالب بلطف للتركيز على الدراسة

أنت هنا لمساعدة الطلاب على الفهم والتعلم، وليس لإعطاء الإجابات الجاهزة.`,
      messages: messages.map((m: any) => ({
        role: m.role,
        content: m.content,
      })),
      maxTokens: 500,
      temperature: 0.7,
    })

    return NextResponse.json({ message: text })
  } catch (error) {
    console.error("[v0] AI chat error:", error)
    return NextResponse.json({ message: "عذراً، حدث خطأ في معالجة طلبك. الرجاء المحاولة مرة أخرى." }, { status: 500 })
  }
}

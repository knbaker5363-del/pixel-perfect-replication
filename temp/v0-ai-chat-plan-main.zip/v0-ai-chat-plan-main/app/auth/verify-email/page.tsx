"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Mail, Clock } from "lucide-react"
import { useSearchParams } from "next/navigation"
import { Suspense } from "react"

function VerifyEmailContent() {
  const searchParams = useSearchParams()
  const isTeacher = searchParams.get("teacher") === "true"

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        <Card className="border-border bg-card text-center">
          <CardHeader>
            <div className="flex justify-center mb-4">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                <Mail className="h-8 w-8 text-primary" />
              </div>
            </div>
            <CardTitle className="text-2xl text-foreground">تحقق من بريدك الإلكتروني</CardTitle>
            <CardDescription className="text-muted-foreground leading-relaxed">
              لقد أرسلنا رابط التفعيل إلى بريدك الإلكتروني. الرجاء النقر على الرابط لتفعيل حسابك.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 rounded-lg bg-muted/50 border border-border">
              <p className="text-sm text-muted-foreground leading-relaxed">
                بعد تفعيل حسابك، سيتم إنشاء ملفك الشخصي تلقائياً وستحصل على 100 نقطة مجانية كهدية ترحيبية
              </p>
            </div>

            {isTeacher && (
              <div className="p-4 rounded-lg bg-orange-500/10 border border-orange-500/20">
                <div className="flex items-start gap-3">
                  <Clock className="h-5 w-5 text-orange-500 mt-0.5 flex-shrink-0" />
                  <div className="text-right">
                    <p className="text-sm font-medium text-orange-500 mb-1">ملاحظة للمدرسين</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      حسابك كمدرس سيكون قيد المراجعة. سيقوم فريق الإدارة بمراجعة طلبك والموافقة عليه قبل أن تتمكن من
                      استقبال الطلاب وإنشاء الجلسات.
                    </p>
                  </div>
                </div>
              </div>
            )}

            <Button asChild variant="outline" className="w-full bg-transparent">
              <Link href="/auth/login">العودة لتسجيل الدخول</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default function VerifyEmailPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-background flex items-center justify-center">
          <p className="text-muted-foreground">جاري التحميل...</p>
        </div>
      }
    >
      <VerifyEmailContent />
    </Suspense>
  )
}

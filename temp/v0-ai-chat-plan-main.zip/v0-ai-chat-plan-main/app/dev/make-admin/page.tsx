import { MakeAdminForm } from "@/components/make-admin-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

export default function MakeAdminPage() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-2xl space-y-4">
        <Link href="/dev">
          <Button variant="ghost" className="gap-2">
            <ArrowLeft className="w-4 h-4" />
            عودة
          </Button>
        </Link>

        <Card className="border-border/50">
          <CardHeader className="text-center space-y-3">
            <div className="flex justify-center">
              <div className="w-16 h-16 rounded-full bg-purple-500/10 flex items-center justify-center">
                <Shield className="w-8 h-8 text-purple-500" />
              </div>
            </div>
            <CardTitle className="text-2xl">إنشاء حساب إدارة</CardTitle>
            <CardDescription>أدخل البريد الإلكتروني للمستخدم الذي تريد تحويله إلى أدمن</CardDescription>
          </CardHeader>

          <CardContent>
            <MakeAdminForm />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { GraduationCap, BookOpen, Sparkles, Shield, Settings } from "lucide-react"

export default function DevAccessPage() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-3xl border-border/50">
        <CardHeader className="text-center space-y-3 pb-8">
          <div className="flex justify-center">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
              <Sparkles className="w-8 h-8 text-primary" />
            </div>
          </div>
          <CardTitle className="text-3xl">وصول المطورين</CardTitle>
          <CardDescription className="text-base">اختر الدور للوصول المباشر إلى لوحة التحكم</CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          <div className="flex flex-col sm:flex-row gap-3 justify-center pb-4 border-b border-border/50">
            <Link href="/admin-access" className="w-full sm:w-auto">
              <Button variant="default" className="w-full gap-2 bg-blue-600 hover:bg-blue-700">
                <Shield className="w-4 h-4" />
                تسجيل دخول الإدارة
              </Button>
            </Link>
            <Link href="/dev/make-admin" className="w-full sm:w-auto">
              <Button variant="outline" className="w-full gap-2 bg-transparent">
                <Settings className="w-4 h-4" />
                إنشاء حساب إدارة
              </Button>
            </Link>
          </div>
          {/* </CHANGE> */}

          <div className="grid md:grid-cols-3 gap-6">
            <Link href="/student" className="block">
              <Card className="h-full hover:border-primary/50 transition-all cursor-pointer group">
                <CardHeader className="text-center space-y-4">
                  <div className="flex justify-center">
                    <div className="w-20 h-20 rounded-full bg-blue-500/10 flex items-center justify-center group-hover:bg-blue-500/20 transition-colors">
                      <GraduationCap className="w-10 h-10 text-blue-500" />
                    </div>
                  </div>
                  <CardTitle className="text-2xl">طالب</CardTitle>
                  <CardDescription>الوصول إلى لوحة تحكم الطالب</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button className="w-full bg-transparent" variant="outline">
                    دخول كطالب
                  </Button>
                </CardContent>
              </Card>
            </Link>

            <Link href="/teacher" className="block">
              <Card className="h-full hover:border-primary/50 transition-all cursor-pointer group">
                <CardHeader className="text-center space-y-4">
                  <div className="flex justify-center">
                    <div className="w-20 h-20 rounded-full bg-emerald-500/10 flex items-center justify-center group-hover:bg-emerald-500/20 transition-colors">
                      <BookOpen className="w-10 h-10 text-emerald-500" />
                    </div>
                  </div>
                  <CardTitle className="text-2xl">مدرس</CardTitle>
                  <CardDescription>الوصول إلى لوحة تحكم المدرس</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button className="w-full bg-transparent" variant="outline">
                    دخول كمدرس
                  </Button>
                </CardContent>
              </Card>
            </Link>

            <Link href="/admin" className="block">
              <Card className="h-full hover:border-primary/50 transition-all cursor-pointer group">
                <CardHeader className="text-center space-y-4">
                  <div className="flex justify-center">
                    <div className="w-20 h-20 rounded-full bg-purple-500/10 flex items-center justify-center group-hover:bg-purple-500/20 transition-colors">
                      <Shield className="w-10 h-10 text-purple-500" />
                    </div>
                  </div>
                  <CardTitle className="text-2xl">إدارة</CardTitle>
                  <CardDescription>الوصول إلى لوحة تحكم الإدارة</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button className="w-full bg-transparent" variant="outline">
                    دخول كإدارة
                  </Button>
                </CardContent>
              </Card>
            </Link>
          </div>
        </CardContent>

        <div className="p-6 pt-2">
          <p className="text-center text-sm text-muted-foreground">هذه الصفحة مؤقتة للتطوير فقط</p>
        </div>
      </Card>
    </div>
  )
}

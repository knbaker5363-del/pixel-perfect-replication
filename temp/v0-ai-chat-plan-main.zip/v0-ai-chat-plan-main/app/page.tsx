import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BookOpen, Users, Award, Clock, FileText, MessageSquare } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="h-8 w-8 text-primary" />
            <h1 className="text-2xl font-bold text-foreground">منصة التدريس</h1>
          </div>
          <div className="flex items-center gap-3">
            <Button asChild variant="secondary" size="sm">
              <Link href="/dev">Dev</Link>
            </Button>
            {/* </CHANGE> */}
            <Button asChild variant="ghost">
              <Link href="/auth/login">تسجيل الدخول</Link>
            </Button>
            <Button asChild>
              <Link href="/auth/signup">التسجيل</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <div className="max-w-3xl mx-auto space-y-6">
          <h2 className="text-5xl font-bold text-foreground leading-tight">
            احجز جلسات دراسية مع أفضل المدرسين الجامعيين
          </h2>
          <p className="text-xl text-muted-foreground leading-relaxed">
            منصة تربط الطلاب بالمدرسين المتخصصين لحجز جلسات تعليمية فردية، مع نظام نقاط داخلي ومساعد ذكاء اصطناعي
          </p>
          <div className="flex items-center justify-center gap-4 pt-4">
            <Button asChild size="lg" className="text-lg px-8">
              <Link href="/auth/signup?role=student">ابدأ كطالب</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="text-lg px-8 bg-transparent">
              <Link href="/auth/signup?role=teacher">انضم كمدرس</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-16">
        <h3 className="text-3xl font-bold text-center mb-12 text-foreground">مميزات المنصة</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="border-border bg-card hover:border-primary/50 transition-colors">
            <CardHeader>
              <Users className="h-12 w-12 text-primary mb-3" />
              <CardTitle className="text-foreground">مدرسون متخصصون</CardTitle>
              <CardDescription className="text-muted-foreground leading-relaxed">
                احجز جلسات مع مدرسين جامعيين متخصصين في مجالات متنوعة
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-border bg-card hover:border-primary/50 transition-colors">
            <CardHeader>
              <Clock className="h-12 w-12 text-primary mb-3" />
              <CardTitle className="text-foreground">حجز مرن</CardTitle>
              <CardDescription className="text-muted-foreground leading-relaxed">
                اختر الوقت المناسب لك واحجز جلستك بكل سهولة
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-border bg-card hover:border-primary/50 transition-colors">
            <CardHeader>
              <Award className="h-12 w-12 text-accent mb-3" />
              <CardTitle className="text-foreground">نظام النقاط</CardTitle>
              <CardDescription className="text-muted-foreground leading-relaxed">
                ابدأ بـ 100 نقطة مجانية واستخدمها لحجز الجلسات والمواد الدراسية
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-border bg-card hover:border-primary/50 transition-colors">
            <CardHeader>
              <FileText className="h-12 w-12 text-accent mb-3" />
              <CardTitle className="text-foreground">مواد دراسية</CardTitle>
              <CardDescription className="text-muted-foreground leading-relaxed">
                احصل على مواد دراسية من المدرسين لدعم تعلمك
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-border bg-card hover:border-primary/50 transition-colors">
            <CardHeader>
              <MessageSquare className="h-12 w-12 text-primary mb-3" />
              <CardTitle className="text-foreground">مساعد ذكي</CardTitle>
              <CardDescription className="text-muted-foreground leading-relaxed">
                احصل على إجابات فورية من مساعد الذكاء الاصطناعي
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-border bg-card hover:border-primary/50 transition-colors">
            <CardHeader>
              <BookOpen className="h-12 w-12 text-accent mb-3" />
              <CardTitle className="text-foreground">تعلم فعال</CardTitle>
              <CardDescription className="text-muted-foreground leading-relaxed">
                جلسات فردية مخصصة تركز على احتياجاتك التعليمية
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20">
        <Card className="border-primary/20 bg-gradient-to-br from-card to-primary/5">
          <CardContent className="p-12 text-center space-y-6">
            <h3 className="text-4xl font-bold text-foreground">ابدأ رحلتك التعليمية اليوم</h3>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              انضم إلى آلاف الطلاب والمدرسين على منصتنا واستفد من نظام التعليم المرن
            </p>
            <Button asChild size="lg" className="text-lg px-8">
              <Link href="/auth/signup">سجل الآن مجاناً</Link>
            </Button>
          </CardContent>
        </Card>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card/50 mt-20">
        <div className="container mx-auto px-4 py-8 text-center text-muted-foreground">
          <p>© 2025 منصة التدريس الجامعي. جميع الحقوق محفوظة.</p>
        </div>
      </footer>
    </div>
  )
}

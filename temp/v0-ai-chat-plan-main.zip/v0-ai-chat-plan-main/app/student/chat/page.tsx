import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { StudentNav } from "@/components/student-nav"
import { ChatInterface } from "@/components/chat-interface"

export default async function StudentChatPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile || profile.role !== "student") {
    redirect("/")
  }

  return (
    <div className="min-h-screen bg-background">
      <StudentNav profile={profile} />

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">المساعد الذكي</h1>
            <p className="text-muted-foreground">احصل على إجابات فورية لأسئلتك الدراسية</p>
          </div>

          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="text-foreground">تحدث مع المساعد</CardTitle>
              <CardDescription className="text-muted-foreground">
                اطرح أي سؤال دراسي وسيساعدك المساعد الذكي
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ChatInterface />
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

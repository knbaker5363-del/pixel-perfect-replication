import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { StudentNav } from "@/components/student-nav"
import { FileText, Download, Award } from "lucide-react"

export default async function StudentMaterialsPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile || profile.role !== "student") {
    redirect("/")
  }

  // Get all materials with teacher info
  const { data: materials } = await supabase
    .from("materials")
    .select(
      `
      *,
      teacher:teachers!inner(
        id,
        specialization,
        profiles!inner(full_name)
      )
    `,
    )
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen bg-background">
      <StudentNav profile={profile} />

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">المواد الدراسية</h1>
          <p className="text-muted-foreground">تصفح وحمل المواد الدراسية من المدرسين</p>
        </div>

        {/* Search */}
        <Card className="border-border bg-card mb-8">
          <CardContent className="pt-6">
            <div className="flex gap-4">
              <Input placeholder="ابحث عن مادة..." className="bg-background text-foreground" dir="rtl" />
              <Button variant="outline" className="bg-transparent">
                بحث
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Materials Grid */}
        {materials && materials.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {materials.map((material: any) => (
              <Card key={material.id} className="border-border bg-card hover:border-primary/50 transition-colors">
                <CardHeader>
                  <div className="flex items-start gap-3 mb-3">
                    <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <FileText className="h-6 w-6 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-lg text-foreground line-clamp-2">{material.title}</CardTitle>
                      <CardDescription className="text-muted-foreground">{material.subject}</CardDescription>
                    </div>
                  </div>
                  {material.description && (
                    <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3">{material.description}</p>
                  )}
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">المدرس:</span>
                      <span className="font-medium text-foreground">{material.teacher.profiles.full_name}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">نوع الملف:</span>
                      <span className="font-medium text-foreground uppercase">{material.file_type}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">التنزيلات:</span>
                      <div className="flex items-center gap-1">
                        <Download className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium text-foreground">{material.download_count}</span>
                      </div>
                    </div>
                    <div className="pt-3 border-t border-border">
                      {material.points_cost === 0 ? (
                        <Button asChild className="w-full bg-transparent" variant="outline">
                          <a href={material.file_url} target="_blank" rel="noopener noreferrer">
                            <Download className="h-4 w-4 mr-2" />
                            تحميل مجاني
                          </a>
                        </Button>
                      ) : (
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-muted-foreground">السعر:</span>
                            <div className="flex items-center gap-1">
                              <Award className="h-4 w-4 text-accent" />
                              <span className="font-bold text-accent">{material.points_cost}</span>
                              <span className="text-sm text-muted-foreground">نقطة</span>
                            </div>
                          </div>
                          <Button
                            asChild
                            className="w-full"
                            disabled={profile.points < material.points_cost}
                            variant={profile.points < material.points_cost ? "outline" : "default"}
                          >
                            <a href={material.file_url} target="_blank" rel="noopener noreferrer">
                              <Download className="h-4 w-4 mr-2" />
                              {profile.points < material.points_cost ? "رصيد غير كافٍ" : "تحميل"}
                            </a>
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-border bg-card">
            <CardContent className="text-center py-12">
              <FileText className="h-12 w-12 text-muted-foreground/50 mx-auto mb-3" />
              <p className="text-muted-foreground">لا توجد مواد دراسية متاحة حالياً</p>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  )
}

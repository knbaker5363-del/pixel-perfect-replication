import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Award, BookOpen, Calendar, Users } from "lucide-react"
import Link from "next/link"
import { StudentNav } from "@/components/student-nav"

export default async function StudentDashboard() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile || profile.role !== "student") {
    redirect("/")
  }

  // Get sessions count
  const { count: sessionsCount } = await supabase
    .from("sessions")
    .select("*", { count: "exact", head: true })
    .eq("student_id", user.id)

  // Get upcoming sessions
  const { data: upcomingSessions } = await supabase
    .from("sessions")
    .select(
      `
      *,
      teacher:teachers!inner(
        id,
        specialization,
        profiles!inner(full_name, avatar_url)
      )
    `,
    )
    .eq("student_id", user.id)
    .gte("scheduled_at", new Date().toISOString())
    .order("scheduled_at", { ascending: true })
    .limit(3)

  // Get available teachers
  const { data: teachers } = await supabase
    .from("teachers")
    .select(
      `
      *,
      profiles!inner(full_name, avatar_url, bio)
    `,
    )
    .eq("is_available", true)
    .limit(6)

  return (
    <div className="min-h-screen bg-background">
      <StudentNav profile={profile} />

      <main className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">مرحباً، {profile.full_name}</h1>
          <p className="text-muted-foreground">لوحة التحكم الخاصة بك</p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="border-border bg-card">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">رصيدك من النقاط</CardTitle>
              <Award className="h-5 w-5 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{profile.points}</div>
              <p className="text-xs text-muted-foreground mt-1">نقطة متاحة للاستخدام</p>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">جلساتك</CardTitle>
              <Calendar className="h-5 w-5 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{sessionsCount || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">إجمالي الجلسات</p>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">المدرسين المتاحين</CardTitle>
              <Users className="h-5 w-5 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{teachers?.length || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">مدرس متاح حالياً</p>
            </CardContent>
          </Card>
        </div>

        {/* Upcoming Sessions */}
        <Card className="border-border bg-card mb-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-foreground">الجلسات القادمة</CardTitle>
                <CardDescription className="text-muted-foreground">جلساتك المجدولة</CardDescription>
              </div>
              <Button asChild variant="outline" className="bg-transparent">
                <Link href="/student/sessions">عرض الكل</Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {upcomingSessions && upcomingSessions.length > 0 ? (
              <div className="space-y-4">
                {upcomingSessions.map((session: any) => (
                  <div
                    key={session.id}
                    className="flex items-center justify-between p-4 rounded-lg bg-muted/50 border border-border"
                  >
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                        <BookOpen className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <p className="font-semibold text-foreground">{session.subject}</p>
                        <p className="text-sm text-muted-foreground">
                          مع {session.teacher.profiles.full_name} - {session.teacher.specialization}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(session.scheduled_at).toLocaleDateString("ar-SA", {
                            weekday: "long",
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-medium ${
                          session.status === "confirmed"
                            ? "bg-accent/10 text-accent"
                            : "bg-muted-foreground/10 text-muted-foreground"
                        }`}
                      >
                        {session.status === "confirmed" ? "مؤكدة" : "قيد الانتظار"}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Calendar className="h-12 w-12 text-muted-foreground/50 mx-auto mb-3" />
                <p className="text-muted-foreground mb-4">لا توجد جلسات قادمة</p>
                <Button asChild>
                  <Link href="/student/teachers">احجز جلسة الآن</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Available Teachers */}
        <Card className="border-border bg-card">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-foreground">المدرسين المتاحين</CardTitle>
                <CardDescription className="text-muted-foreground">تصفح المدرسين واحجز جلسة</CardDescription>
              </div>
              <Button asChild variant="outline" className="bg-transparent">
                <Link href="/student/teachers">عرض الكل</Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {teachers && teachers.length > 0 ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {teachers.map((teacher: any) => (
                  <div key={teacher.id} className="p-4 rounded-lg bg-muted/50 border border-border">
                    <div className="flex items-start gap-3 mb-3">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Users className="h-6 w-6 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-foreground truncate">{teacher.profiles.full_name}</h3>
                        <p className="text-sm text-muted-foreground">{teacher.specialization}</p>
                      </div>
                    </div>
                    {teacher.profiles.bio && (
                      <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{teacher.profiles.bio}</p>
                    )}
                    <div className="flex items-center justify-between">
                      <div className="text-sm">
                        <span className="text-accent font-semibold">{teacher.hourly_rate}</span>
                        <span className="text-muted-foreground"> نقطة/ساعة</span>
                      </div>
                      <Button asChild size="sm">
                        <Link href={`/student/teachers/${teacher.id}`}>احجز</Link>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Users className="h-12 w-12 text-muted-foreground/50 mx-auto mb-3" />
                <p className="text-muted-foreground">لا يوجد مدرسين متاحين حالياً</p>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { StudentNav } from "@/components/student-nav"
import { Calendar, BookOpen } from "lucide-react"

export default async function StudentSessionsPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile || profile.role !== "student") {
    redirect("/")
  }

  // Get all sessions
  const { data: sessions } = await supabase
    .from("sessions")
    .select(
      `
      *,
      teacher:teachers!inner(
        id,
        specialization,
        profiles!inner(full_name, avatar_url)
      )
    `,
    )
    .eq("student_id", user.id)
    .order("scheduled_at", { ascending: false })

  const upcomingSessions = sessions?.filter((s) => new Date(s.scheduled_at) >= new Date()) || []
  const pastSessions = sessions?.filter((s) => new Date(s.scheduled_at) < new Date()) || []

  return (
    <div className="min-h-screen bg-background">
      <StudentNav profile={profile} />

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">جلساتي</h1>
          <p className="text-muted-foreground">جميع جلساتك الدراسية</p>
        </div>

        {/* Upcoming Sessions */}
        <Card className="border-border bg-card mb-8">
          <CardHeader>
            <CardTitle className="text-foreground">الجلسات القادمة</CardTitle>
            <CardDescription className="text-muted-foreground">
              الجلسات المجدولة ({upcomingSessions.length})
            </CardDescription>
          </CardHeader>
          <CardContent>
            {upcomingSessions.length > 0 ? (
              <div className="space-y-4">
                {upcomingSessions.map((session: any) => (
                  <div
                    key={session.id}
                    className="flex items-center justify-between p-4 rounded-lg bg-muted/50 border border-border"
                  >
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                        <BookOpen className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <p className="font-semibold text-foreground">{session.subject}</p>
                        <p className="text-sm text-muted-foreground">
                          مع {session.teacher.profiles.full_name} - {session.teacher.specialization}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(session.scheduled_at).toLocaleDateString("ar-SA", {
                            weekday: "long",
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-muted-foreground">{session.duration_minutes} دقيقة</span>
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-medium ${
                          session.status === "confirmed"
                            ? "bg-accent/10 text-accent"
                            : session.status === "completed"
                              ? "bg-primary/10 text-primary"
                              : session.status === "cancelled"
                                ? "bg-destructive/10 text-destructive"
                                : "bg-muted-foreground/10 text-muted-foreground"
                        }`}
                      >
                        {session.status === "confirmed"
                          ? "مؤكدة"
                          : session.status === "completed"
                            ? "مكتملة"
                            : session.status === "cancelled"
                              ? "ملغاة"
                              : "قيد الانتظار"}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Calendar className="h-12 w-12 text-muted-foreground/50 mx-auto mb-3" />
                <p className="text-muted-foreground">لا توجد جلسات قادمة</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Past Sessions */}
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="text-foreground">الجلسات السابقة</CardTitle>
            <CardDescription className="text-muted-foreground">سجل الجلسات ({pastSessions.length})</CardDescription>
          </CardHeader>
          <CardContent>
            {pastSessions.length > 0 ? (
              <div className="space-y-4">
                {pastSessions.map((session: any) => (
                  <div
                    key={session.id}
                    className="flex items-center justify-between p-4 rounded-lg bg-muted/50 border border-border opacity-75"
                  >
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center">
                        <BookOpen className="h-6 w-6 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="font-semibold text-foreground">{session.subject}</p>
                        <p className="text-sm text-muted-foreground">
                          مع {session.teacher.profiles.full_name} - {session.teacher.specialization}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(session.scheduled_at).toLocaleDateString("ar-SA", {
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                          })}
                        </p>
                      </div>
                    </div>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        session.status === "completed"
                          ? "bg-primary/10 text-primary"
                          : "bg-destructive/10 text-destructive"
                      }`}
                    >
                      {session.status === "completed" ? "مكتملة" : "ملغاة"}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Calendar className="h-12 w-12 text-muted-foreground/50 mx-auto mb-3" />
                <p className="text-muted-foreground">لا توجد جلسات سابقة</p>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

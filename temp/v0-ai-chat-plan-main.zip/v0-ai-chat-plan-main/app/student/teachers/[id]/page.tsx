import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { StudentNav } from "@/components/student-nav"
import { Users, Star, Award, BookOpen } from "lucide-react"
import { BookSessionForm } from "@/components/book-session-form"

export default async function TeacherProfilePage({ params }: { params: { id: string } }) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile || profile.role !== "student") {
    redirect("/")
  }

  // Get teacher info
  const { data: teacher } = await supabase
    .from("teachers")
    .select(
      `
      *,
      profiles!inner(full_name, avatar_url, bio, email, phone)
    `,
    )
    .eq("id", params.id)
    .single()

  if (!teacher) {
    redirect("/student/teachers")
  }

  // Get teacher's reviews
  const { data: reviews } = await supabase
    .from("reviews")
    .select(
      `
      *,
      student:profiles!reviews_student_id_fkey(full_name)
    `,
    )
    .eq("teacher_id", params.id)
    .order("created_at", { ascending: false })
    .limit(5)

  return (
    <div className="min-h-screen bg-background">
      <StudentNav profile={profile} />

      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Teacher Info */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-border bg-card">
              <CardHeader>
                <div className="flex items-start gap-6">
                  <div className="h-24 w-24 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Users className="h-12 w-12 text-primary" />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-2xl text-foreground mb-2">{teacher.profiles.full_name}</CardTitle>
                    <CardDescription className="text-lg text-muted-foreground mb-4">
                      {teacher.specialization}
                    </CardDescription>
                    <div className="flex items-center gap-6">
                      <div className="flex items-center gap-2">
                        <Star className="h-5 w-5 text-accent fill-accent" />
                        <span className="font-semibold text-foreground">{teacher.rating.toFixed(1)}</span>
                        <span className="text-sm text-muted-foreground">({reviews?.length || 0} تقييم)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <BookOpen className="h-5 w-5 text-primary" />
                        <span className="font-semibold text-foreground">{teacher.total_sessions}</span>
                        <span className="text-sm text-muted-foreground">جلسة</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardHeader>
              {teacher.profiles.bio && (
                <CardContent>
                  <h3 className="font-semibold text-foreground mb-2">نبذة عن المدرس</h3>
                  <p className="text-muted-foreground leading-relaxed">{teacher.profiles.bio}</p>
                </CardContent>
              )}
            </Card>

            {/* Reviews */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-foreground">تقييمات الطلاب</CardTitle>
                <CardDescription className="text-muted-foreground">
                  آراء الطلاب السابقين ({reviews?.length || 0})
                </CardDescription>
              </CardHeader>
              <CardContent>
                {reviews && reviews.length > 0 ? (
                  <div className="space-y-4">
                    {reviews.map((review: any) => (
                      <div key={review.id} className="p-4 rounded-lg bg-muted/50 border border-border">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-semibold text-foreground">{review.student.full_name}</span>
                          <div className="flex items-center gap-1">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star
                                key={i}
                                className={`h-4 w-4 ${
                                  i < review.rating
                                    ? "text-accent fill-accent"
                                    : "text-muted-foreground/30 fill-muted-foreground/30"
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                        {review.comment && (
                          <p className="text-sm text-muted-foreground leading-relaxed">{review.comment}</p>
                        )}
                        <p className="text-xs text-muted-foreground mt-2">
                          {new Date(review.created_at).toLocaleDateString("ar-SA", {
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                          })}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Star className="h-10 w-10 text-muted-foreground/50 mx-auto mb-2" />
                    <p className="text-sm text-muted-foreground">لا توجد تقييمات حتى الآن</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Booking Form */}
          <div>
            <Card className="border-primary/20 bg-gradient-to-br from-card to-primary/5 sticky top-24">
              <CardHeader>
                <CardTitle className="text-foreground">احجز جلسة</CardTitle>
                <CardDescription className="text-muted-foreground">املأ البيانات لحجز جلسة مع المدرس</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-6 p-4 rounded-lg bg-muted/50 border border-border">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">السعر بالساعة</span>
                    <div className="flex items-center gap-1">
                      <Award className="h-4 w-4 text-accent" />
                      <span className="text-lg font-bold text-accent">{teacher.hourly_rate}</span>
                      <span className="text-sm text-muted-foreground">نقطة</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">رصيدك الحالي</span>
                    <span className="text-sm font-semibold text-foreground">{profile.points} نقطة</span>
                  </div>
                </div>
                <BookSessionForm
                  teacherId={teacher.id}
                  teacherRate={teacher.hourly_rate}
                  studentPoints={profile.points}
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { TeacherNav } from "@/components/teacher-nav"
import { Award, TrendingUp } from "lucide-react"

export default async function TeacherEarningsPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile || profile.role !== "teacher") {
    redirect("/")
  }

  // Get earning transactions
  const { data: transactions } = await supabase
    .from("points_transactions")
    .select("*")
    .eq("user_id", user.id)
    .eq("type", "session_earning")
    .order("created_at", { ascending: false })

  const totalEarnings = transactions?.reduce((sum, t) => sum + t.amount, 0) || 0

  return (
    <div className="min-h-screen bg-background">
      <TeacherNav profile={profile} />

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">سجل الأرباح</h1>
          <p className="text-muted-foreground">تتبع أرباحك من الجلسات التدريسية</p>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="border-border bg-gradient-to-br from-card to-accent/5">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="h-16 w-16 rounded-full bg-accent/10 flex items-center justify-center">
                  <Award className="h-8 w-8 text-accent" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">رصيدك الحالي</p>
                  <p className="text-4xl font-bold text-foreground">{profile.points}</p>
                  <p className="text-sm text-muted-foreground">نقطة</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border bg-gradient-to-br from-card to-primary/5">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                  <TrendingUp className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">إجمالي الأرباح</p>
                  <p className="text-4xl font-bold text-foreground">{totalEarnings}</p>
                  <p className="text-sm text-muted-foreground">نقطة</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Transactions */}
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="text-foreground">سجل الأرباح</CardTitle>
            <CardDescription className="text-muted-foreground">
              أرباحك من الجلسات ({transactions?.length || 0})
            </CardDescription>
          </CardHeader>
          <CardContent>
            {transactions && transactions.length > 0 ? (
              <div className="space-y-3">
                {transactions.map((transaction: any) => (
                  <div
                    key={transaction.id}
                    className="flex items-center justify-between p-4 rounded-lg bg-muted/50 border border-border"
                  >
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 rounded-full flex items-center justify-center bg-accent/10">
                        <TrendingUp className="h-5 w-5 text-accent" />
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{transaction.description}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(transaction.created_at).toLocaleDateString("ar-SA", {
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </p>
                      </div>
                    </div>
                    <div className="text-lg font-bold text-accent">+{transaction.amount}</div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Award className="h-12 w-12 text-muted-foreground/50 mx-auto mb-3" />
                <p className="text-muted-foreground">لا توجد أرباح حتى الآن</p>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { TeacherNav } from "@/components/teacher-nav"
import { AddMaterialForm } from "@/components/add-material-form"

export default async function NewMaterialPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile || profile.role !== "teacher") {
    redirect("/")
  }

  return (
    <div className="min-h-screen bg-background">
      <TeacherNav profile={profile} />

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">إضافة مادة دراسية جديدة</h1>
            <p className="text-muted-foreground">قم برفع مادة دراسية ليستفيد منها الطلاب</p>
          </div>

          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="text-foreground">معلومات المادة</CardTitle>
              <CardDescription className="text-muted-foreground">املأ البيانات أدناه لإضافة المادة</CardDescription>
            </CardHeader>
            <CardContent>
              <AddMaterialForm />
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

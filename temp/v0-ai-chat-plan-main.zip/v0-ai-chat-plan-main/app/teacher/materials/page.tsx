import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { TeacherNav } from "@/components/teacher-nav"
import { FileText, Download, Plus } from "lucide-react"
import Link from "next/link"

export default async function TeacherMaterialsPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile || profile.role !== "teacher") {
    redirect("/")
  }

  // Get teacher's materials
  const { data: materials } = await supabase
    .from("materials")
    .select("*")
    .eq("teacher_id", user.id)
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen bg-background">
      <TeacherNav profile={profile} />

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">المواد الدراسية</h1>
            <p className="text-muted-foreground">إدارة موادك الدراسية</p>
          </div>
          <Button asChild>
            <Link href="/teacher/materials/new">
              <Plus className="h-4 w-4 mr-2" />
              إضافة مادة جديدة
            </Link>
          </Button>
        </div>

        {materials && materials.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {materials.map((material: any) => (
              <Card key={material.id} className="border-border bg-card">
                <CardHeader>
                  <div className="flex items-start gap-3 mb-3">
                    <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <FileText className="h-6 w-6 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-lg text-foreground line-clamp-2">{material.title}</CardTitle>
                      <CardDescription className="text-muted-foreground">{material.subject}</CardDescription>
                    </div>
                  </div>
                  {material.description && (
                    <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3">{material.description}</p>
                  )}
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">نوع الملف:</span>
                      <span className="font-medium text-foreground uppercase">{material.file_type}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">السعر:</span>
                      <span className="font-semibold text-accent">
                        {material.points_cost === 0 ? "مجاني" : `${material.points_cost} نقطة`}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">التنزيلات:</span>
                      <div className="flex items-center gap-1">
                        <Download className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium text-foreground">{material.download_count}</span>
                      </div>
                    </div>
                    <div className="pt-3 border-t border-border">
                      <p className="text-xs text-muted-foreground">
                        نُشر في {new Date(material.created_at).toLocaleDateString("ar-SA")}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-border bg-card">
            <CardContent className="text-center py-12">
              <FileText className="h-12 w-12 text-muted-foreground/50 mx-auto mb-3" />
              <p className="text-muted-foreground mb-4">لم تقم بإضافة أي مواد دراسية بعد</p>
              <Button asChild>
                <Link href="/teacher/materials/new">
                  <Plus className="h-4 w-4 mr-2" />
                  إضافة مادة جديدة
                </Link>
              </Button>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  )
}

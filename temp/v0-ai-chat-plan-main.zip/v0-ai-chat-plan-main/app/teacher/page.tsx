import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Award, Calendar, FileText, Users, Star } from "lucide-react"
import Link from "next/link"
import { TeacherNav } from "@/components/teacher-nav"

export default async function TeacherDashboard() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get profile and teacher info
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile || profile.role !== "teacher") {
    redirect("/")
  }

  const { data: teacher } = await supabase.from("teachers").select("*").eq("id", user.id).single()

  // Get sessions stats
  const { count: totalSessions } = await supabase
    .from("sessions")
    .select("*", { count: "exact", head: true })
    .eq("teacher_id", user.id)

  const { count: upcomingCount } = await supabase
    .from("sessions")
    .select("*", { count: "exact", head: true })
    .eq("teacher_id", user.id)
    .gte("scheduled_at", new Date().toISOString())

  // Get upcoming sessions
  const { data: upcomingSessions } = await supabase
    .from("sessions")
    .select(
      `
      *,
      student:profiles!sessions_student_id_fkey(full_name, avatar_url)
    `,
    )
    .eq("teacher_id", user.id)
    .gte("scheduled_at", new Date().toISOString())
    .order("scheduled_at", { ascending: true })
    .limit(5)

  // Get materials count
  const { count: materialsCount } = await supabase
    .from("materials")
    .select("*", { count: "exact", head: true })
    .eq("teacher_id", user.id)

  return (
    <div className="min-h-screen bg-background">
      <TeacherNav profile={profile} />

      <main className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">مرحباً، {profile.full_name}</h1>
          <p className="text-muted-foreground">لوحة تحكم المدرس</p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="border-border bg-card">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">رصيد النقاط</CardTitle>
              <Award className="h-5 w-5 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{profile.points}</div>
              <p className="text-xs text-muted-foreground mt-1">نقطة</p>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">إجمالي الجلسات</CardTitle>
              <Calendar className="h-5 w-5 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{totalSessions || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">جلسة</p>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">الجلسات القادمة</CardTitle>
              <Users className="h-5 w-5 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{upcomingCount || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">جلسة مجدولة</p>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">التقييم</CardTitle>
              <Star className="h-5 w-5 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{teacher?.rating?.toFixed(1) || "0.0"}</div>
              <p className="text-xs text-muted-foreground mt-1">من 5.0</p>
            </CardContent>
          </Card>
        </div>

        {/* Teacher Info Card */}
        <Card className="border-primary/20 bg-gradient-to-br from-card to-primary/5 mb-8">
          <CardContent className="pt-6">
            <div className="flex items-start justify-between">
              <div className="space-y-2">
                <h3 className="text-xl font-bold text-foreground">معلوماتك التدريسية</h3>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">
                    <span className="font-medium text-foreground">التخصص:</span> {teacher?.specialization}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    <span className="font-medium text-foreground">السعر:</span> {teacher?.hourly_rate} نقطة/ساعة
                  </p>
                  <p className="text-sm text-muted-foreground">
                    <span className="font-medium text-foreground">الحالة:</span>{" "}
                    {teacher?.is_available ? (
                      <span className="text-accent">متاح للحجز</span>
                    ) : (
                      <span className="text-destructive">غير متاح</span>
                    )}
                  </p>
                </div>
              </div>
              <Button asChild>
                <Link href="/teacher/profile">تعديل الملف</Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Sessions */}
        <Card className="border-border bg-card mb-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-foreground">الجلسات القادمة</CardTitle>
                <CardDescription className="text-muted-foreground">جلساتك المجدولة</CardDescription>
              </div>
              <Button asChild variant="outline" className="bg-transparent">
                <Link href="/teacher/sessions">عرض الكل</Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {upcomingSessions && upcomingSessions.length > 0 ? (
              <div className="space-y-4">
                {upcomingSessions.map((session: any) => (
                  <div
                    key={session.id}
                    className="flex items-center justify-between p-4 rounded-lg bg-muted/50 border border-border"
                  >
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                        <Users className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <p className="font-semibold text-foreground">{session.subject}</p>
                        <p className="text-sm text-muted-foreground">مع الطالب: {session.student.full_name}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(session.scheduled_at).toLocaleDateString("ar-SA", {
                            weekday: "long",
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-muted-foreground">{session.duration_minutes} دقيقة</span>
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-medium ${
                          session.status === "confirmed"
                            ? "bg-accent/10 text-accent"
                            : "bg-muted-foreground/10 text-muted-foreground"
                        }`}
                      >
                        {session.status === "confirmed" ? "مؤكدة" : "قيد الانتظار"}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Calendar className="h-12 w-12 text-muted-foreground/50 mx-auto mb-3" />
                <p className="text-muted-foreground">لا توجد جلسات قادمة</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="border-border bg-card hover:border-primary/50 transition-colors">
            <CardHeader>
              <FileText className="h-10 w-10 text-primary mb-3" />
              <CardTitle className="text-foreground">المواد الدراسية</CardTitle>
              <CardDescription className="text-muted-foreground">
                لديك {materialsCount || 0} مادة دراسية منشورة
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild className="w-full">
                <Link href="/teacher/materials">إدارة المواد</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="border-border bg-card hover:border-primary/50 transition-colors">
            <CardHeader>
              <Award className="h-10 w-10 text-accent mb-3" />
              <CardTitle className="text-foreground">سجل النقاط</CardTitle>
              <CardDescription className="text-muted-foreground">تتبع أرباحك من الجلسات</CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild variant="outline" className="w-full bg-transparent">
                <Link href="/teacher/earnings">عرض الأرباح</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

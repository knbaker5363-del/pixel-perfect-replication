import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { TeacherNav } from "@/components/teacher-nav"
import { User, Mail, Phone, Calendar, Award, BookOpen } from "lucide-react"

export default async function TeacherProfilePage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile || profile.role !== "teacher") {
    redirect("/")
  }

  const { data: teacher } = await supabase.from("teachers").select("*").eq("id", user.id).single()

  return (
    <div className="min-h-screen bg-background">
      <TeacherNav profile={profile} />

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">الملف الشخصي</h1>
            <p className="text-muted-foreground">معلوماتك الشخصية والتدريسية</p>
          </div>

          <Card className="border-border bg-card mb-6">
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center">
                  <User className="h-10 w-10 text-primary" />
                </div>
                <div>
                  <CardTitle className="text-2xl text-foreground">{profile.full_name}</CardTitle>
                  <CardDescription className="text-muted-foreground">مدرس - {teacher?.specialization}</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <Mail className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">البريد الإلكتروني</p>
                    <p className="text-sm font-medium text-foreground">{profile.email}</p>
                  </div>
                </div>

                {profile.phone && (
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                    <Phone className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">رقم الهاتف</p>
                      <p className="text-sm font-medium text-foreground">{profile.phone}</p>
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <Calendar className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">تاريخ التسجيل</p>
                    <p className="text-sm font-medium text-foreground">
                      {new Date(profile.created_at).toLocaleDateString("ar-SA", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </p>
                  </div>
                </div>
              </div>

              {profile.bio && (
                <div className="p-4 rounded-lg bg-muted/50">
                  <p className="text-xs text-muted-foreground mb-2">نبذة</p>
                  <p className="text-sm text-foreground leading-relaxed">{profile.bio}</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="text-foreground">المعلومات التدريسية</CardTitle>
              <CardDescription className="text-muted-foreground">بيانات نشاطك التدريسي</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <BookOpen className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-xs text-muted-foreground">التخصص</p>
                  <p className="text-sm font-medium text-foreground">{teacher?.specialization}</p>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <Award className="h-5 w-5 text-accent" />
                <div>
                  <p className="text-xs text-muted-foreground">السعر بالساعة</p>
                  <p className="text-sm font-medium text-foreground">{teacher?.hourly_rate} نقطة</p>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <Calendar className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">الحالة</p>
                  <p className="text-sm font-medium text-foreground">
                    {teacher?.is_available ? "متاح للحجز" : "غير متاح"}
                  </p>
                </div>
              </div>

              <Button variant="outline" className="w-full bg-transparent" disabled>
                تعديل المعلومات (قريباً)
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"

export function AddMaterialForm() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    fileUrl: "",
    fileType: "pdf",
    subject: "",
    pointsCost: "0",
  })
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()

      // Get current user
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        setError("يجب تسجيل الدخول أولاً")
        setIsLoading(false)
        return
      }

      // Insert material
      const { error: materialError } = await supabase.from("materials").insert({
        teacher_id: user.id,
        title: formData.title,
        description: formData.description || null,
        file_url: formData.fileUrl,
        file_type: formData.fileType,
        subject: formData.subject,
        points_cost: Number.parseInt(formData.pointsCost),
      })

      if (materialError) throw materialError

      // Success - redirect to materials page
      router.push("/teacher/materials")
      router.refresh()
    } catch (err: unknown) {
      console.error("[v0] Add material error:", err)
      setError(err instanceof Error ? err.message : "حدث خطأ في إضافة المادة")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="title" className="text-foreground">
          عنوان المادة
        </Label>
        <Input
          id="title"
          type="text"
          required
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          className="bg-background text-foreground"
          placeholder="مثال: ملخص قوانين التفاضل والتكامل"
          dir="rtl"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="subject" className="text-foreground">
          المادة الدراسية
        </Label>
        <Input
          id="subject"
          type="text"
          required
          value={formData.subject}
          onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
          className="bg-background text-foreground"
          placeholder="مثال: رياضيات، فيزياء، برمجة"
          dir="rtl"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description" className="text-foreground">
          وصف المادة (اختياري)
        </Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          className="bg-background text-foreground min-h-24"
          placeholder="اكتب وصفاً مختصراً عن محتوى المادة..."
          dir="rtl"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="fileUrl" className="text-foreground">
          رابط الملف
        </Label>
        <Input
          id="fileUrl"
          type="url"
          required
          value={formData.fileUrl}
          onChange={(e) => setFormData({ ...formData, fileUrl: e.target.value })}
          className="bg-background text-foreground"
          placeholder="https://example.com/file.pdf"
          dir="ltr"
        />
        <p className="text-xs text-muted-foreground">يمكنك رفع الملف على Google Drive أو Dropbox ووضع الرابط هنا</p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="fileType" className="text-foreground">
          نوع الملف
        </Label>
        <Select value={formData.fileType} onValueChange={(value) => setFormData({ ...formData, fileType: value })}>
          <SelectTrigger className="bg-background text-foreground">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="pdf">PDF</SelectItem>
            <SelectItem value="doc">Word Document</SelectItem>
            <SelectItem value="ppt">PowerPoint</SelectItem>
            <SelectItem value="video">فيديو</SelectItem>
            <SelectItem value="other">آخر</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="pointsCost" className="text-foreground">
          السعر بالنقاط
        </Label>
        <Input
          id="pointsCost"
          type="number"
          required
          value={formData.pointsCost}
          onChange={(e) => setFormData({ ...formData, pointsCost: e.target.value })}
          className="bg-background text-foreground"
          min="0"
          placeholder="0"
        />
        <p className="text-xs text-muted-foreground">ضع 0 إذا كنت تريد المادة مجانية</p>
      </div>

      {error && (
        <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20">
          <p className="text-sm text-destructive">{error}</p>
        </div>
      )}

      <Button type="submit" className="w-full" disabled={isLoading}>
        {isLoading ? "جاري الإضافة..." : "إضافة المادة"}
      </Button>
    </form>
  )
}

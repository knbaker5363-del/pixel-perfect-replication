"use client"

import { Button } from "@/components/ui/button"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { useState } from "react"
import { CheckCircle } from "lucide-react"

export function ApproveTeacherButton({ teacherId, adminId }: { teacherId: string; adminId: string }) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)

  const handleApprove = async () => {
    setIsLoading(true)
    try {
      const supabase = createClient()
      const { error } = await supabase.rpc("approve_teacher", {
        teacher_id: teacherId,
        admin_id: adminId,
      })

      if (error) throw error

      router.refresh()
    } catch (error) {
      console.error("[v0] Error approving teacher:", error)
      alert("حدث خطأ في قبول المدرس")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Button onClick={handleApprove} disabled={isLoading} className="flex-1">
      <CheckCircle className="h-4 w-4 ml-2" />
      {isLoading ? "جاري القبول..." : "قبول المدرس"}
    </Button>
  )
}

"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"

interface BookSessionFormProps {
  teacherId: string
  teacherRate: number
  studentPoints: number
}

export function BookSessionForm({ teacherId, teacherRate, studentPoints }: BookSessionFormProps) {
  const router = useRouter()
  const [formData, setFormData] = useState({
    subject: "",
    description: "",
    scheduledDate: "",
    scheduledTime: "",
    duration: "60",
  })
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const calculateCost = () => {
    const durationHours = Number.parseInt(formData.duration) / 60
    return Math.round(teacherRate * durationHours)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    const cost = calculateCost()

    if (cost > studentPoints) {
      setError("رصيدك من النقاط غير كافٍ لحجز هذه الجلسة")
      setIsLoading(false)
      return
    }

    if (!formData.scheduledDate || !formData.scheduledTime) {
      setError("الرجاء تحديد التاريخ والوقت")
      setIsLoading(false)
      return
    }

    try {
      const supabase = createClient()

      // Get current user
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        setError("يجب تسجيل الدخول أولاً")
        setIsLoading(false)
        return
      }

      // Combine date and time
      const scheduledAt = new Date(`${formData.scheduledDate}T${formData.scheduledTime}`)

      // Create session
      const { error: sessionError } = await supabase.from("sessions").insert({
        student_id: user.id,
        teacher_id: teacherId,
        subject: formData.subject,
        description: formData.description || null,
        scheduled_at: scheduledAt.toISOString(),
        duration_minutes: Number.parseInt(formData.duration),
        points_cost: cost,
        status: "pending",
      })

      if (sessionError) throw sessionError

      // Success - redirect to sessions page
      router.push("/student/sessions?booked=true")
      router.refresh()
    } catch (err: unknown) {
      console.error("[v0] Booking error:", err)
      setError(err instanceof Error ? err.message : "حدث خطأ في الحجز")
    } finally {
      setIsLoading(false)
    }
  }

  const cost = calculateCost()

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="subject" className="text-foreground">
          موضوع الجلسة
        </Label>
        <Input
          id="subject"
          type="text"
          required
          value={formData.subject}
          onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
          className="bg-background text-foreground"
          placeholder="مثال: شرح التفاضل والتكامل"
          dir="rtl"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description" className="text-foreground">
          تفاصيل إضافية (اختياري)
        </Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          className="bg-background text-foreground min-h-20"
          placeholder="اكتب تفاصيل عن ما تريد تعلمه..."
          dir="rtl"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="scheduledDate" className="text-foreground">
          التاريخ
        </Label>
        <Input
          id="scheduledDate"
          type="date"
          required
          value={formData.scheduledDate}
          onChange={(e) => setFormData({ ...formData, scheduledDate: e.target.value })}
          className="bg-background text-foreground"
          min={new Date().toISOString().split("T")[0]}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="scheduledTime" className="text-foreground">
          الوقت
        </Label>
        <Input
          id="scheduledTime"
          type="time"
          required
          value={formData.scheduledTime}
          onChange={(e) => setFormData({ ...formData, scheduledTime: e.target.value })}
          className="bg-background text-foreground"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="duration" className="text-foreground">
          مدة الجلسة
        </Label>
        <Select value={formData.duration} onValueChange={(value) => setFormData({ ...formData, duration: value })}>
          <SelectTrigger className="bg-background text-foreground">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="30">30 دقيقة</SelectItem>
            <SelectItem value="60">ساعة واحدة</SelectItem>
            <SelectItem value="90">ساعة ونصف</SelectItem>
            <SelectItem value="120">ساعتان</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="p-4 rounded-lg bg-muted border border-border space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">التكلفة الإجمالية:</span>
          <span className="text-lg font-bold text-accent">{cost} نقطة</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">الرصيد بعد الحجز:</span>
          <span className={`font-semibold ${studentPoints - cost >= 0 ? "text-foreground" : "text-destructive"}`}>
            {studentPoints - cost} نقطة
          </span>
        </div>
      </div>

      {error && (
        <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20">
          <p className="text-sm text-destructive">{error}</p>
        </div>
      )}

      <Button type="submit" className="w-full" disabled={isLoading || cost > studentPoints}>
        {isLoading ? "جاري الحجز..." : cost > studentPoints ? "رصيد غير كافٍ" : "احجز الآن"}
      </Button>

      <p className="text-xs text-muted-foreground text-center leading-relaxed">
        بالحجز أنت توافق على خصم {cost} نقطة من رصيدك. سيتم الخصم بعد تأكيد المدرس للجلسة.
      </p>
    </form>
  )
}

"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle2, AlertCircle, Loader2 } from "lucide-react"

export function MakeAdminForm() {
  const [email, setEmail] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{ type: "success" | "error"; message: string } | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setResult(null)

    try {
      const response = await fetch("/api/admin/make-admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      })

      const data = await response.json()

      if (response.ok) {
        setResult({
          type: "success",
          message: `تم تحويل ${email} إلى أدمن بنجاح! يمكنك الآن الدخول كإدارة.`,
        })
        setEmail("")
      } else {
        setResult({
          type: "error",
          message: data.error || "حدث خطأ أثناء التحويل",
        })
      }
    } catch (error) {
      setResult({
        type: "error",
        message: "حدث خطأ في الاتصال بالخادم",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="email">البريد الإلكتروني</Label>
        <Input
          id="email"
          type="email"
          placeholder="admin@example.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          disabled={loading}
          dir="ltr"
          className="text-left"
        />
      </div>

      {result && (
        <Alert variant={result.type === "error" ? "destructive" : "default"} className="border-border/50">
          {result.type === "success" ? (
            <CheckCircle2 className="h-4 w-4 text-green-500" />
          ) : (
            <AlertCircle className="h-4 w-4" />
          )}
          <AlertDescription>{result.message}</AlertDescription>
        </Alert>
      )}

      <Button type="submit" className="w-full" disabled={loading}>
        {loading && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
        تحويل إلى أدمن
      </Button>

      <p className="text-xs text-muted-foreground text-center">ملاحظة: يجب أن يكون المستخدم مسجل بالفعل في النظام</p>
    </form>
  )
}

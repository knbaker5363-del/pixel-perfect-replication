"use client"

import { Button } from "@/components/ui/button"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { useState } from "react"
import { XCircle } from "lucide-react"

export function RejectTeacherButton({ teacherId, adminId }: { teacherId: string; adminId: string }) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)

  const handleReject = async () => {
    if (!confirm("هل أنت متأكد من رفض هذا المدرس؟")) {
      return
    }

    setIsLoading(true)
    try {
      const supabase = createClient()
      const { error } = await supabase.rpc("reject_teacher", {
        teacher_id: teacherId,
        admin_id: adminId,
      })

      if (error) throw error

      router.refresh()
    } catch (error) {
      console.error("[v0] Error rejecting teacher:", error)
      alert("حدث خطأ في رفض المدرس")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Button onClick={handleReject} disabled={isLoading} variant="destructive" className="flex-1">
      <XCircle className="h-4 w-4 ml-2" />
      {isLoading ? "جاري الرفض..." : "رفض المدرس"}
    </Button>
  )
}

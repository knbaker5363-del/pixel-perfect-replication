export type UserRole = "student" | "teacher"

export interface Profile {
  id: string
  email: string
  full_name: string
  role: UserRole
  phone?: string
  bio?: string
  avatar_url?: string
  points: number
  created_at: string
  updated_at: string
}

export interface Teacher {
  id: string
  specialization: string
  hourly_rate: number
  is_available: boolean
  total_sessions: number
  rating: number
  created_at: string
}

export interface Session {
  id: string
  student_id: string
  teacher_id: string
  subject: string
  description?: string
  scheduled_at: string
  duration_minutes: number
  points_cost: number
  status: "pending" | "confirmed" | "completed" | "cancelled"
  meeting_link?: string
  notes?: string
  created_at: string
  updated_at: string
}

export interface Material {
  id: string
  teacher_id: string
  title: string
  description?: string
  file_url: string
  file_type: string
  subject: string
  points_cost: number
  download_count: number
  created_at: string
}

export interface PointsTransaction {
  id: string
  user_id: string
  amount: number
  type: string
  description: string
  related_id?: string
  created_at: string
}

export interface Review {
  id: string
  session_id: string
  student_id: string
  teacher_id: string
  rating: number
  comment?: string
  created_at: string
}

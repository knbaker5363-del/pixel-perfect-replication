-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create enum for user roles
CREATE TYPE user_role AS ENUM ('student', 'teacher');

-- Users/Profiles table (extends Supabase auth.users)
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT NOT NULL,
  role user_role NOT NULL,
  phone TEXT,
  bio TEXT,
  avatar_url TEXT,
  points INTEGER DEFAULT 100, -- Students start with 100 points
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Teachers table (additional teacher info)
CREATE TABLE teachers (
  id UUID PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  specialization TEXT NOT NULL,
  hourly_rate INTEGER NOT NULL, -- In points
  is_available BOOLEAN DEFAULT true,
  total_sessions INTEGER DEFAULT 0,
  rating DECIMAL(3,2) DEFAULT 0.0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Sessions table (booking system)
CREATE TABLE sessions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  teacher_id UUID NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
  subject TEXT NOT NULL,
  description TEXT,
  scheduled_at TIMESTAMPTZ NOT NULL,
  duration_minutes INTEGER NOT NULL DEFAULT 60,
  points_cost INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', -- pending, confirmed, completed, cancelled
  meeting_link TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Materials table (study materials uploaded by teachers)
CREATE TABLE materials (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  teacher_id UUID NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  file_url TEXT NOT NULL,
  file_type TEXT NOT NULL, -- pdf, doc, video, etc
  subject TEXT NOT NULL,
  points_cost INTEGER NOT NULL DEFAULT 0, -- 0 means free
  download_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Points transactions table (track all point movements)
CREATE TABLE points_transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  amount INTEGER NOT NULL, -- Positive for earning, negative for spending
  type TEXT NOT NULL, -- 'session_payment', 'material_purchase', 'signup_bonus', 'session_earning'
  description TEXT NOT NULL,
  related_id UUID, -- ID of related session or material
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Reviews table (students review teachers after sessions)
CREATE TABLE reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  session_id UUID NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  teacher_id UUID NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(session_id, student_id)
);

-- Create indexes for better performance
CREATE INDEX idx_sessions_student ON sessions(student_id);
CREATE INDEX idx_sessions_teacher ON sessions(teacher_id);
CREATE INDEX idx_sessions_scheduled ON sessions(scheduled_at);
CREATE INDEX idx_materials_teacher ON materials(teacher_id);
CREATE INDEX idx_materials_subject ON materials(subject);
CREATE INDEX idx_points_transactions_user ON points_transactions(user_id);
CREATE INDEX idx_reviews_teacher ON reviews(teacher_id);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE teachers ENABLE ROW LEVEL SECURITY;
ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE materials ENABLE ROW LEVEL SECURITY;
ALTER TABLE points_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Users can view all profiles" ON profiles FOR SELECT USING (true);
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users can insert own profile" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- RLS Policies for teachers
CREATE POLICY "Anyone can view teachers" ON teachers FOR SELECT USING (true);
CREATE POLICY "Teachers can update own info" ON teachers FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Teachers can insert own info" ON teachers FOR INSERT WITH CHECK (auth.uid() = id);

-- RLS Policies for sessions
CREATE POLICY "Users can view their own sessions" ON sessions FOR SELECT 
  USING (auth.uid() = student_id OR auth.uid() = teacher_id);
CREATE POLICY "Students can create sessions" ON sessions FOR INSERT 
  WITH CHECK (auth.uid() = student_id);
CREATE POLICY "Participants can update sessions" ON sessions FOR UPDATE 
  USING (auth.uid() = student_id OR auth.uid() = teacher_id);

-- RLS Policies for materials
CREATE POLICY "Anyone can view materials" ON materials FOR SELECT USING (true);
CREATE POLICY "Teachers can insert materials" ON materials FOR INSERT 
  WITH CHECK (auth.uid() = teacher_id);
CREATE POLICY "Teachers can update own materials" ON materials FOR UPDATE 
  USING (auth.uid() = teacher_id);
CREATE POLICY "Teachers can delete own materials" ON materials FOR DELETE 
  USING (auth.uid() = teacher_id);

-- RLS Policies for points_transactions
CREATE POLICY "Users can view own transactions" ON points_transactions FOR SELECT 
  USING (auth.uid() = user_id);
CREATE POLICY "System can insert transactions" ON points_transactions FOR INSERT 
  WITH CHECK (true); -- Will be handled by server-side functions

-- RLS Policies for reviews
CREATE POLICY "Anyone can view reviews" ON reviews FOR SELECT USING (true);
CREATE POLICY "Students can insert reviews" ON reviews FOR INSERT 
  WITH CHECK (auth.uid() = student_id);
CREATE POLICY "Students can update own reviews" ON reviews FOR UPDATE 
  USING (auth.uid() = student_id);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for updated_at
CREATE TRIGGER profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER sessions_updated_at BEFORE UPDATE ON sessions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Function to create profile after user signup and email confirmation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Insert profile only when email is confirmed
  IF NEW.email_confirmed_at IS NOT NULL AND OLD.email_confirmed_at IS NULL THEN
    INSERT INTO public.profiles (id, email, full_name, role, phone, bio, points)
    VALUES (
      NEW.id,
      NEW.email,
      COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
      COALESCE((NEW.raw_user_meta_data->>'role')::user_role, 'student'),
      NEW.raw_user_meta_data->>'phone',
      NEW.raw_user_meta_data->>'bio',
      100 -- Starting points
    );

    -- If teacher, create teacher record with pending approval status
    IF (NEW.raw_user_meta_data->>'role') = 'teacher' THEN
      INSERT INTO public.teachers (id, specialization, hourly_rate, approval_status)
      VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'specialization', 'عام'),
        COALESCE((NEW.raw_user_meta_data->>'hourly_rate')::integer, 50),
        'pending' -- Teachers start as pending approval
      );
    END IF;

    -- Create welcome transaction
    INSERT INTO public.points_transactions (user_id, amount, type, description)
    VALUES (NEW.id, 100, 'signup_bonus', 'مكافأة التسجيل في المنصة');
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger on auth.users table
DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Function to handle session confirmation by teacher
CREATE OR REPLACE FUNCTION confirm_session(session_id UUID)
RETURNS VOID AS $$
DECLARE
  v_student_id UUID;
  v_teacher_id UUID;
  v_points_cost INTEGER;
BEGIN
  -- Get session details
  SELECT student_id, teacher_id, points_cost
  INTO v_student_id, v_teacher_id, v_points_cost
  FROM sessions
  WHERE id = session_id AND status = 'pending';

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Session not found or already processed';
  END IF;

  -- Update session status
  UPDATE sessions SET status = 'confirmed' WHERE id = session_id;

  -- Deduct points from student
  UPDATE profiles SET points = points - v_points_cost WHERE id = v_student_id;

  -- Add transaction for student (spending)
  INSERT INTO points_transactions (user_id, amount, type, description, related_id)
  VALUES (v_student_id, -v_points_cost, 'session_payment', 'دفع تكلفة الجلسة', session_id);

  -- Add points to teacher
  UPDATE profiles SET points = points + v_points_cost WHERE id = v_teacher_id;

  -- Add transaction for teacher (earning)
  INSERT INTO points_transactions (user_id, amount, type, description, related_id)
  VALUES (v_teacher_id, v_points_cost, 'session_earning', 'أرباح من جلسة تدريسية', session_id);

  -- Update teacher stats
  UPDATE teachers SET total_sessions = total_sessions + 1 WHERE id = v_teacher_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to handle session cancellation
CREATE OR REPLACE FUNCTION cancel_session(session_id UUID, cancelled_by UUID)
RETURNS VOID AS $$
DECLARE
  v_session RECORD;
BEGIN
  -- Get session details
  SELECT * INTO v_session
  FROM sessions
  WHERE id = session_id AND status IN ('pending', 'confirmed');

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Session not found or cannot be cancelled';
  END IF;

  -- If session was confirmed, refund student
  IF v_session.status = 'confirmed' THEN
    -- Refund student
    UPDATE profiles SET points = points + v_session.points_cost WHERE id = v_session.student_id;
    
    -- Deduct from teacher
    UPDATE profiles SET points = points - v_session.points_cost WHERE id = v_session.teacher_id;
    
    -- Add refund transaction for student
    INSERT INTO points_transactions (user_id, amount, type, description, related_id)
    VALUES (v_session.student_id, v_session.points_cost, 'session_refund', 'استرجاع تكلفة جلسة ملغاة', session_id);
    
    -- Add deduction transaction for teacher
    INSERT INTO points_transactions (user_id, amount, type, description, related_id)
    VALUES (v_session.teacher_id, -v_session.points_cost, 'session_refund', 'خصم بسبب إلغاء جلسة', session_id);
  END IF;

  -- Update session status
  UPDATE sessions SET status = 'cancelled' WHERE id = session_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to complete session
CREATE OR REPLACE FUNCTION complete_session(session_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE sessions SET status = 'completed' WHERE id = session_id AND status = 'confirmed';
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Session not found or not confirmed';
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

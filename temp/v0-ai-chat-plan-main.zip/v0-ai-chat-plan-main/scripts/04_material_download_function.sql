-- Function to handle material download with payment
CREATE OR REPLACE FUNCTION download_material(material_id UUID, student_id UUID)
RETURNS VOID AS $$
DECLARE
  v_material RECORD;
  v_student_points INTEGER;
BEGIN
  -- Get material details
  SELECT * INTO v_material
  FROM materials
  WHERE id = material_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Material not found';
  END IF;

  -- If material is free, just increment download count
  IF v_material.points_cost = 0 THEN
    UPDATE materials SET download_count = download_count + 1 WHERE id = material_id;
    RETURN;
  END IF;

  -- Get student points
  SELECT points INTO v_student_points
  FROM profiles
  WHERE id = student_id;

  -- Check if student has enough points
  IF v_student_points < v_material.points_cost THEN
    RAISE EXCEPTION 'Insufficient points';
  END IF;

  -- Deduct points from student
  UPDATE profiles SET points = points - v_material.points_cost WHERE id = student_id;

  -- Add points to teacher
  UPDATE profiles SET points = points + v_material.points_cost WHERE id = v_material.teacher_id;

  -- Add transaction for student (spending)
  INSERT INTO points_transactions (user_id, amount, type, description, related_id)
  VALUES (student_id, -v_material.points_cost, 'material_purchase', 'شراء مادة دراسية: ' || v_material.title, material_id);

  -- Add transaction for teacher (earning)
  INSERT INTO points_transactions (user_id, amount, type, description, related_id)
  VALUES (v_material.teacher_id, v_material.points_cost, 'material_sale', 'بيع مادة دراسية: ' || v_material.title, material_id);

  -- Increment download count
  UPDATE materials SET download_count = download_count + 1 WHERE id = material_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add admin role to user_role enum
ALTER TYPE user_role ADD VALUE IF NOT EXISTS 'admin';

-- Add approval status to teachers table
ALTER TABLE teachers ADD COLUMN IF NOT EXISTS approval_status TEXT NOT NULL DEFAULT 'pending';
ALTER TABLE teachers ADD COLUMN IF NOT EXISTS approval_date TIMESTAMPTZ;
ALTER TABLE teachers ADD COLUMN IF NOT EXISTS approved_by UUID REFERENCES profiles(id);

-- Add check constraint for approval_status
ALTER TABLE teachers ADD CONSTRAINT teachers_approval_status_check 
  CHECK (approval_status IN ('pending', 'approved', 'rejected'));

-- Update existing teachers to be approved (migration for existing data)
UPDATE teachers SET approval_status = 'approved' WHERE approval_status = 'pending';

-- RLS Policy: Only approved teachers can be seen by students
DROP POLICY IF EXISTS "Anyone can view teachers" ON teachers;
CREATE POLICY "Anyone can view approved teachers" ON teachers FOR SELECT 
  USING (approval_status = 'approved' OR auth.uid() = id);

-- RLS Policy: Admins can update teacher approval
CREATE POLICY "Admins can update teacher approval" ON teachers FOR UPDATE 
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

-- Function to approve teacher
CREATE OR REPLACE FUNCTION approve_teacher(teacher_id UUID, admin_id UUID)
RETURNS VOID AS $$
BEGIN
  -- Check if admin
  IF NOT EXISTS (SELECT 1 FROM profiles WHERE id = admin_id AND role = 'admin') THEN
    RAISE EXCEPTION 'Only admins can approve teachers';
  END IF;
  
  -- Update teacher status
  UPDATE teachers 
  SET 
    approval_status = 'approved',
    approval_date = NOW(),
    approved_by = admin_id
  WHERE id = teacher_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to reject teacher
CREATE OR REPLACE FUNCTION reject_teacher(teacher_id UUID, admin_id UUID)
RETURNS VOID AS $$
BEGIN
  -- Check if admin
  IF NOT EXISTS (SELECT 1 FROM profiles WHERE id = admin_id AND role = 'admin') THEN
    RAISE EXCEPTION 'Only admins can reject teachers';
  END IF;
  
  -- Update teacher status
  UPDATE teachers 
  SET 
    approval_status = 'rejected',
    approval_date = NOW(),
    approved_by = admin_id
  WHERE id = teacher_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create first admin user (you can modify the email)
-- This script should be run manually after creating your first user account

-- Update an existing user to admin (replace 'your-email@example.com' with your actual email)
UPDATE profiles 
SET role = 'admin' 
WHERE email = 'admin@example.com';

-- Note: You need to create a user first through the signup page, 
-- then update this script with your email and run it to make yourself an admin
